var http=require('http');
var porta = process.env.PORT || 8090;
http.createServer(function(req, res){
    res.writeHead(200, {'Content-Type':'text/plain'});
    res.end('Servidor criado pelo Node.js!\n');
}).listen(porta, '127.0.0.1')